#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAX 200

int mystrcmp(char *, char *);
