#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAX 32
int myatoi(char *);
void mystrncpy(char *, char *, int);
