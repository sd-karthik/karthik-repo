#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX 32

int strrot(char *, char *);
extern int myatoi(char *);
