#include<stdio.h>
#include<stdlib.h>
#define MAX 32 /*define MAX value as 32 */

char *remsstr(char *, char *);
extern int myatoi(char *);
int str_len(char *);


