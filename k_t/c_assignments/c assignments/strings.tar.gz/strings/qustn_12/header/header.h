#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define MAX 32 /*define MAX value as 32 */

void squeezstr(char *);
extern int myatoi(char *);



