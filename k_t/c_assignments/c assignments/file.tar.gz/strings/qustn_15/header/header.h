#include<stdio.h>
#include<stdlib.h>
#define MAX 32 /*define MAX value as 32 */

int str_len(char *);
void insertchar(char *, char, int);
extern int myatoi(char *);



