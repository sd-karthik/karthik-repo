
/* this function copying the characters from source to destination 
		upto NULL termination occurance */


void *mystrcpy(char *dst, char *str)
{
	while(*dst++ = *str++); 

	*dst = '\0';

}
	

