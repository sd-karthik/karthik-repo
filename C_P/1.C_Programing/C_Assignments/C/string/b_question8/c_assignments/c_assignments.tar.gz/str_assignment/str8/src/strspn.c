#include "header1.h" 

int strsp(char *sbu, char *dbu)
{ 
	int j;  
    int i;	
	
	for(i=0,j=0; *(sbu+i+1)!='\0';j++){
			if((*(sbu+i) == *(dbu+j)) && (*(dbu+j+1) != '\0')){
			i++;
			}
			else if(i>0)
				break;
				}
		
	return i; 

}
