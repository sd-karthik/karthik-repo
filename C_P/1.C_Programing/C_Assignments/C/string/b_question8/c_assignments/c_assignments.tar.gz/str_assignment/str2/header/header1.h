#include <stdio.h>

#include <string.h>

#include <stdlib.h>

#define MAX 64

void str_cpy(char *sbuf , char *dbuf);

extern int valid(char str[MAX]);

void copy_n(char *sbu,char *dbu, int n);
