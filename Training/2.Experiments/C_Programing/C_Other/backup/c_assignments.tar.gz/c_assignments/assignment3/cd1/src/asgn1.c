#include"header1.h"

int main (int argc, char *argv[])
{
//	if(argc != )
//		printf("arguments insufficient\n");
	
	printf ("number of files in folder %d",(argc-1));
}
