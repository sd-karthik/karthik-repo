#include <stdio.h>                                                           
#include<stdlib.h>                                                              
#include<string.h>
int valid(char *str);   
void add (int a , int b);
void sub (int a , int b);
void mul (int a , int b);
void divide (int a , int b);
