#include<stdio.h>

int main()
{


	int i,j;
	switch (i)
{
case 0 : printf("1");break;
case j : printf ("10");break;
}
}
