#include<stdio.h>
#include<string.h>
#define MAX 32

int main()

{
	int i;
	char s[MAX];
	fgets (s)








}
