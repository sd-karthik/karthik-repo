#include<stdio.h>
#include<stdlib.h>

#define limit 10                                                                
int stack[limit];                                                                  
int top;                                                                                                                             

void push (int element);                                                 
void pop (void);                                                          
                                               
                                                                  
   
