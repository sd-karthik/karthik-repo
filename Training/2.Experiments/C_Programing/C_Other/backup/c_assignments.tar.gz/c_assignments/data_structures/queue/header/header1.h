#include <stdio.h>

int f;
int r;

# define limit 5

int queue[limit];

void enqueue (int ele);
void dequeue (void);
void dequeue (void);
