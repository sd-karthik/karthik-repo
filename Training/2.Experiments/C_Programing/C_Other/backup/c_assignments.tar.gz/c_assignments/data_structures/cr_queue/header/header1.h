#include <stdio.h>

# define limit 5

int queue[limit];

void enqueue (int ele);
void dequeue (void);
void dequeue (void);
