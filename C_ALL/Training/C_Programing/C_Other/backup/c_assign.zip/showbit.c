#include<stdio.h>

int showbit(int num)
{
	int i;
	for(i=31; i>=0;i--) {
		printf("%d", 1 & (num>>i));
	}
	return 0;
}
