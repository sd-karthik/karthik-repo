
#ifndef _DSHEADER_H
#define _DSHEADER_H

extern void push(void);
extern void pop(void);
extern void display(void);
extern int my_atoi(char *);
int isempty(void);
int isfull(void);

extern void enqueue(void);
extern void dequeue(void);
extern void que_display(void);
extern int que_isfull(void);
extern int que_isempty(void);

void cir_enque(void);
void cir_deque(void);
int cir_isfull(void);
int cir_isempty(void);
void cir_display();

void sll_insert_menu(void);
void sll_delete_menu(void);

int isfirstnode(void);
void insert_at_beg(void);
void sll_display(void);
void insert_at_end(void);
int search(int);
void insert_at_pos(int);
void insert_before_number(int);
void insert_after_number(int);
void insert_at_mid(void);
void insert_at_penultimate(void);

int del_isfirstnode(void);
void delete_at_beg(void);
void del_sll_display(void);
void delete_at_end(void);
int del_search(int);
void delete_at_pos(int);
void delete_before_number(int);
void delete_after_number(int);
void delete_at_mid(void);
void delete_at_penultimate(void);

void dll_menu(void);
void dll_insert_at_beg(void);
void dll_display(void);
void dll_insert_at_end(void);
void dll_insert_at_pos(int);
int dll_search(int);
void dll_insert_before_number(int);
void dll_insert_after_number(int);
void dll_insert_at_mid(void);
void dll_insert_at_penultimate(void);

void dll_delete_at_beg(void);
void dll_delete_at_end(void);
void dll_delete_at_pos(int);
void dll_delete_before_number(int);
void dll_delete_after_number(int);
void dll_delete_at_mid(void);
void dll_delete_at_penultimate(void);

int isfirstc_node(void);
void cir_insert_at_beg(void);
void cir_sll_display(void);
void cir_insert_at_end(void);
int cir_search(int);
void cir_insert_at_c_pos(int);
void cir_insert_before_number(int);
void cir_insert_after_number(int);
void cir_insert_at_mid(void);
void cir_insert_at_penultimate(void);

void cir_sll_menu(void);

int del_isfirstc_node(void);
void cir_delete_at_beg(void);
void cir_del_sll_display(void);
void cir_delete_at_end(void);
int cir_del_search(int);
void cir_delete_at_c_pos(int);
void cir_delete_before_number(int);
void cir_delete_after_number(int);
void cir_delete_at_mid(void);
void cir_delete_at_penultimate(void);

void copy_node_to_file(void);
#endif
