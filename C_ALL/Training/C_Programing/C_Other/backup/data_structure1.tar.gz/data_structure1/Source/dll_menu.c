#include <stdio.h>
#include <stdlib.h>
#include "../Header/dsheader.h"
#define MAX 5
void dll_menu(void)
{
	char choice[MAX];
	int pos;
	int data;
	/*	char input[MAX];
		int pos;
		int data;*/

	do {
		//		system("clear");
		printf("1.InsertAtBeg\n2.InsertAtEnd\n3.Insert at given position\n");
		printf("4.Insert Before Given Pos\n5.Insert after given position\t");
		printf("6.Insert Before given number\n7.Insert after given number\t");
		printf("8.Insert at the middle\n9.Insert at penumltimate\n");
		printf("10.DeleteAtBeg\n11.DeleteAtEnd\n12.DeleteAtGivenPos\t");
		printf("13.Delete Before Given Pos\n14.Delete after given position\t");
		printf("15.Delete before given number\n16.Delete after given number\t");
		printf("17.Delete at the middle"
				"\n18.Delete at penumltimate\n19.Display\n");
		printf("20.Exit\n");

		if(NULL == (fgets(choice, MAX, stdin))) {

			perror("fgets failed\n");
			exit(1);
		}
		switch(my_atoi(choice)) {

			case 1 : dll_insert_at_beg();
					 break;

			case 19 : dll_display();
					  break;

			case 2 : dll_insert_at_end();
					 break;

			case 3 :
					 printf("Enter position : ");
					 scanf("%d",&pos);
					 dll_insert_at_pos((pos - 1));
					 break;

			case 4 : printf("Enter position : ");
					 scanf("%d", &pos);
					 dll_insert_at_pos((pos - 1));
					 break;

			case 5 : printf("Enter position : ");
					 scanf("%d", &pos);
					 dll_insert_at_pos(pos);
					 break;

			case 6 : printf("Enter number : ");
					 scanf("%d", &data);
					 dll_insert_before_number(data);
					 break;

			case 7 : printf("Enter data : ");
					 scanf("%d", &data);
					 dll_insert_after_number(data);
					 break;

			case 8 : dll_insert_at_mid();
					 break;

			case 9 : dll_insert_at_penultimate();
					 break;
			case 10 : dll_delete_at_beg ();
					  break;

			case 11 : dll_delete_at_end();
					  break;

			case 12 : printf("Enter position : ");
					  scanf("%d", &pos);
					  dll_delete_at_pos(pos);
					  break;
			case 13 : printf("Enter position : ");
					  scanf("%d", &pos);
					  dll_delete_at_pos((pos - 1));
					  break;

			case 14 : printf("Enter position : ");
					  scanf("%d", &pos);
					  dll_delete_at_pos((pos + 1));
					  break;

			case 15 : printf("Enter number : ");
					  scanf("%d", &data);
					  dll_delete_before_number(data);
					  break;

			case 16 :  printf("Enter number : ");
					  scanf("%d", &data);
					  dll_delete_after_number(data);
					  break;

			case 17 : dll_delete_at_mid();
					  break;

			case 18 : dll_delete_at_penultimate();
					  break;

			case 20 :  exit(1);
		}
	}while(1);
}
