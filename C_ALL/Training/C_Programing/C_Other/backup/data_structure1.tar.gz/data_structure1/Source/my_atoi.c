#include<stdio.h>
int my_atoi(char *);
int my_strlen(char *);

int my_atoi(char *arr)
{
	int value = 0;
	int i = 0;

	while(arr[i] != '\n') {
					if(arr[i] >= 48 && arr[i] <= 57) {
						value *= 10;
						value += arr[i] - 48;
						i++;
				}
			}
			return value;
}

int my_strlen(char *str)
{
	int i = 0;
	while(*(str + i)) {
		i++;
	}
	return i;
}
