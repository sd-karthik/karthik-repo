#include<stdio.h>
#include<stdlib.h>
#include "../Header/dsheader.h"

int count = 0;
struct d_node {
	int data;
	struct d_node *llink;
	struct d_node *rlink;
};
struct d_node *d_start = NULL, *d_temp;

void dll_insert_at_beg(void)
{
	if(NULL == (d_temp = (struct d_node *) malloc (sizeof(struct d_node)))) {
		perror("malloc failed\n");
		exit(1);
	}
	printf("Enter data : ");
	scanf("%d", &(d_temp -> data));

	if(d_start == NULL) {
		d_temp -> llink = NULL;
		d_temp -> rlink = NULL;
		d_start = d_temp;
		count++;
		printf("Node added\n");
		dll_display();
		return;

	} else {
		//	scanf("%d", &(d_temp -> data));
		d_temp -> llink = NULL;
		d_temp -> rlink = d_start;
		d_start -> llink = d_temp;
		d_start = d_temp;
		count++;
		printf("Node added\n");
		dll_display();
		return;
	}
}

void dll_insert_at_end(void)
{
	if(d_start == NULL) {
		dll_insert_at_beg();
		return;
	} else {
		printf("Enter data  : ");
		struct d_node *t;
		d_temp = (struct d_node *) malloc (sizeof(struct d_node));
		t = d_start;
		while(t -> rlink != NULL) {
			t = t -> rlink;
		}
		scanf("%d", &(d_temp -> data));
		d_temp -> rlink = NULL;
		d_temp -> llink = t;
		t -> rlink = d_temp;
		count++;
		return;
	}
}

void dll_insert_at_pos(int pos)
{
	if(pos < 0 || pos > (count + 1)) {
		printf("Invalid choice, Node does not exist\n");
		return;
	} else if (pos == (count + 1)) {
		dll_insert_at_end();
		return;
	} else if (pos == 0) {
		dll_insert_at_beg();
		return;
	} else {
		struct d_node *t;
		t = d_start;
		while(--pos) {
			t = t -> rlink;
		}
		d_temp = (struct d_node *) malloc (sizeof(struct d_node)); 
		printf("Enter data : ");
		scanf("%d", &(d_temp -> data));
		d_temp -> llink = t;
		d_temp -> rlink = t -> rlink;
		t -> rlink = d_temp;
		count++;
		return;
	}
}

int dll_search(int data)
{
	int pos = 1;
	struct d_node *t;
	t = d_start;
	if(d_start == NULL) {
		printf("List is empty\n");
		return 0;
	} else if (t -> data == data) {
		return 1;
	} else {
		while(t -> data != data) {
			t = t -> rlink;
			pos++;
		}
		if(t -> data == data) {
			return pos;
		} else {
			return 0;
		}
	}
	return 0;
}

void dll_insert_before_number(int data)
{
	int pos = dll_search(data);
	printf("pos : %d\n", pos);
	if(pos == 0) {
		printf("Invalid choice \n");
		return;
	} else {
		dll_insert_at_pos((pos - 1));
		return;
	}
}

void dll_insert_after_number(int data)
{
	int pos = dll_search(data);
	printf("pos : %d\n", pos);
	if(pos == 0) {
		printf("Invalid choice \n");
		return;
	} else {
		dll_insert_at_pos(pos);
		return;
	}
}

void dll_insert_at_mid(void)
{
	dll_insert_at_pos((count / 2));
}

void dll_insert_at_penultimate(void)
{
	dll_insert_at_pos((count - 1));
}

void dll_delete_at_beg (void)
{
	if(d_start == NULL) {
		printf("List is empty\n");
		return;
	} else if(d_start -> rlink == NULL) {
		free(d_start);
		d_start = NULL;
		count--;
	} else {
		struct d_node *t = d_start;
		t -> rlink -> llink = NULL;
		d_start = t -> rlink;
		free(t);
		t = NULL;
		count--;
		return;
	}
}

void dll_delete_at_end(void)
{
	if(d_start == NULL) {
		printf("List is empty\n");
		return;
	} else if(d_start -> rlink == NULL) {
		dll_delete_at_beg();
		return;
	} else {
		printf("Hello\n");
		struct d_node *t = d_start;
		while(t -> rlink != NULL) {
			t = t -> rlink;
		}

		t -> llink -> rlink = NULL;
		free(t);
		t = NULL;
		count--;
		return;
	}
}

void dll_delete_at_pos(int pos)
{
	if(pos == 0 || pos > count) {
		printf("Node does not exist\n");
		return;
	} else if(pos == 1) {
		dll_delete_at_beg();
		return;
	} else if (pos == count) {
		dll_delete_at_end();
		return;
	} else {
		struct d_node *t = d_start;
		while (--pos) {
			t =  t -> rlink;
		}

		t -> llink -> rlink = t -> rlink;
		t -> rlink -> llink = t -> llink;
		free(t);
		t  = NULL;
		count--;
		return;
	}
}

void dll_delete_before_number (int data) 
{
	int pos = dll_search(data);
	printf("pos%d\n : ", pos);
	if(pos == 0) {
		printf("Number not found\n");
		return;
	} else {
		dll_delete_at_pos((pos - 1));
		return;
	}
}

void dll_delete_after_number (int data) 
{
	int pos = dll_search(data);
	printf("pos%d\n : ", pos);
	if(pos == 0) {
		printf("Number not found\n");
		return;
	} else {
		dll_delete_at_pos((pos + 1));
		return;
	}
}

void dll_delete_at_mid(void)
{
	if(count % 2 == 0) {
	dll_delete_at_pos((count / 2));
	} else {
		dll_delete_at_pos(((count / 2) + 1));
	}
	return;
}

void dll_delete_at_penultimate(void)
{
	dll_delete_at_pos((count - 1));
	return;
}

void dll_display(void)
{
	if(d_start == NULL) {
		printf("List is empty\n");
		return;
	} else {
		printf("Count : %d\n", count);
		d_temp = d_start;
		while(d_temp -> rlink != NULL) {
			printf("%d -> ", d_temp -> data);
			d_temp = d_temp -> rlink;
		}
		printf("%d\n", d_temp -> data);
		return;
	}
}
