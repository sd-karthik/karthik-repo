
#include<stdio.h>
#include <stdlib.h>
#include "../Header/dsheader.h"
#define MAX 5

int arr[MAX];
char input[MAX];
int front = -1;
int rear = -1;

void enqueue(void)
{
	if(que_isfull()) {		//Checks if queue is full

		printf("Queue is full\n");
		return;

	} else if (rear == (MAX - 1) && front != 0) {	/*checks if front not at 0th
													place when rear is at end*/
		int i = 0;
		int f = front;

		for(i = 0; i <= (rear - front); i++) {	/*shifts all values to leftmost
												locations to add next element*/
			arr[i] = arr[f++];
		}
	
		front = 0;
		rear = i;
		
		printf("Enter the element : ");

		if(NULL == (fgets(input, MAX, stdin))) {
			perror("fgets failed\n");
			exit(1);
		}
		arr[rear] = (my_atoi(input));

	} else if (front == -1 && rear == -1) {		/*To insert element in queue for 
												  the first time*/
		printf("Enter the element : ");

		if(NULL == (fgets(input, MAX, stdin))) {
			perror("fgets failed\n");
			exit(1);
		}

		arr[++rear] = (my_atoi(input));
		front++;

	} else {										/*add element at rear */

		printf("Enter the element : ");

		if(NULL == (fgets(input, MAX, stdin))) {
			perror("fgets failed\n");
			exit(1);
		}

		arr[++rear] = (my_atoi(input));
	}		
}

void dequeue(void)								/*Delete element from queue*/
{
	(que_isempty()) ? printf("Queue is empty") : front++ ;
}

void que_display(void)						/*displaying all the elements*/
{
	int i = front;

	while(i <= rear) {

		printf("arr[%d] %d\n", i, arr[i]);
		i++;
	}
}

int que_isfull(void)					/*checks if queue is full*/
{
	return (rear == (MAX - 1) && front == 0) ? 1 : 0;
}

int que_isempty(void)					/*checks if queue is empty*/
{
	return (front > rear) ? 1 : 0;
}
