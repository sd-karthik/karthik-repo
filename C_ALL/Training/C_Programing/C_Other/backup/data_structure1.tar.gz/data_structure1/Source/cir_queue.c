
#include<stdio.h>
#include<stdlib.h>
#include "../Header/dsheader.h"
#define MAX 5

char in[MAX];
int cir_arr[MAX];
int cir_front = -1;
int cir_rear = -1;

void cir_enque(void)
{
	if(cir_isfull()) {

		printf("Queue is full\n");
		return;

	} else if(-1 ==  cir_front && -1 ==  cir_rear) {
		
		printf("Enter the element : ");

		if(NULL == (fgets(in, MAX, stdin))) {
			perror("fgets failed\n");
			exit(1);
		}
		cir_front++;
		cir_rear = (cir_rear + 1) % MAX ;
		cir_arr[cir_rear] = my_atoi(in);
	} else {

		printf("Enter the element : ");

		if(NULL == (fgets(in, MAX, stdin))) {
			perror("fgets failed\n");
			exit(1);
		}

		cir_rear = (cir_rear + 1) % MAX;
		cir_arr[cir_rear] = my_atoi(in);
	}
}

void cir_deque(void)
{
	if(cir_isempty()) {
		printf("Queue is empty");
		return;
	} else if(cir_front == cir_rear) {
		cir_front = cir_rear = -1;
	} else {
		cir_front++;
	}
}
int cir_isfull(void)
{
	return ((cir_front == 0 && cir_rear == (MAX - 1)) || (cir_rear == (cir_front - 1))) ? 1 : 0;
}

int cir_isempty(void)
{
	return (cir_front == -1 && cir_rear == -1) ? 1 : 0;
}

void cir_display(void)
{
	int i = cir_front;
	if(cir_isempty()) {
		printf("Queue is empty \n");
		return;
	} else if(cir_front <= cir_rear) {
		while(i <= cir_rear) {
			printf("arr[%d] : %d\n", i , cir_arr[i]);
			i++;
		}
	} else {
		while(i != MAX) {
			printf("arr[%d] : %d\n", i, cir_arr[i]);
			i++;
		}
			i = 0;
			while(i <= cir_rear) {
				printf("arr[%d] : %d\n", i, cir_arr[i]);
				i++;
			}
		}
}
