#include<stdio.h>
#include<stdlib.h>
#include "../Header/dsheader.h"

int pos = 1;
int cnt = 0;

struct node {
	int data;
	struct node *link;
};

struct node *start = NULL, *temp;

int isfirstnode(void)
{
	if(start == NULL) {
		printf("Enter data (first node ) : ");
		temp = (struct node *) malloc (sizeof(struct node));
		scanf("%d", &(temp -> data));
		temp -> link = NULL;
		start = temp;
		cnt++;
		return 1;
	} else {
		return 0;
	}
}

void insert_at_beg(void)
{
	if(isfirstnode()) {

		printf("Data added successfully\n");
		return;

	} else {
		printf("Enter data (insert at beg) : ");
		temp = (struct node *) malloc (sizeof(struct node));
		scanf("%d", &(temp -> data));
		temp -> link = start;
		start = temp;
		cnt++;
		return;
	}
}
void insert_at_end(void)
{
	if(isfirstnode()) {

		return;

	} else {
		struct node *t = start;

		while(t -> link != NULL) {

			t = t -> link;
		}

		printf("Enter data : ");
		temp = (struct node *) malloc (sizeof (struct node));
		scanf("%d", &(temp -> data));
		temp -> link = NULL;
		t -> link = temp;
		cnt++;
	}
	return;
}
int search(int data)
{
	pos = 0;
	temp = start;
	if (temp -> data ==  data) {
		return 1;
	} else {
		while(temp -> data != data) {

			temp = temp -> link;
			pos++;
		}
		return pos;
	}
}

void insert_at_pos(int pos)
{
	if(isfirstnode()) {
		return;
	} else {
		printf("pos : %d\n", pos);
		if(pos == 0) {
			insert_at_beg();
			return;
		} else if (pos == (cnt + 1)) {
			insert_at_end();
			return;
		} else {
			if(pos <= cnt) {
				temp = start;
				while(--pos) {
					temp = temp -> link;
				}
				struct node *temp2 = (struct node *) malloc (sizeof(struct node));
				printf("Enter data : ");
				scanf("%d", &(temp2 -> data));
				temp2 -> link = temp -> link;
				temp -> link = temp2;
				cnt++;
				return;
			} else {
				printf("Enter a valid position less than %d ", cnt);
				return;
			}
		}
	}
}

void insert_before_number(int num)
{
	int pos = search(num);
	if(pos == 0) {
		printf("Number not found \n");
		return;
	} else {
		insert_at_pos((pos));
		return;
	}
}

void insert_after_number(int num)
{
	int pos = search(num);
	if(pos == 0) {
		printf("Number not found \n");
		return;
	} else {
		insert_at_pos((pos + 1));
		return;
	}
}

void insert_at_mid(void)
{
	if(cnt % 2 != 0) {
		insert_at_pos((cnt / 2) + 1);
		return;
	}  else {
		insert_at_pos((cnt / 2));
		return;
	}
	return;
}

void insert_at_penultimate(void)
{
	insert_at_pos((cnt - 1));
}

void delete_at_beg(void)
{
	if(start == NULL) {
		printf("List is empty\n");
		return;
	} else if(start -> link == NULL) {
		temp = start;
		start = NULL;
		free(temp);
		temp = NULL;
		cnt--;
		return;
	} else {
		temp = start;
		start = temp -> link;
		free(temp);
		temp = NULL;
		cnt--;
		return;
	}
}

void delete_at_end(void)
{
	if(start == NULL) {
		printf("List is empty\n ");
		return;
	} else {
		struct node *t;
		temp = start;

		if(temp -> link == NULL) {
			start = NULL;
			free(temp);
			temp = NULL;
			cnt--;
			return;
		} else  {
			while(temp -> link != NULL) {
				t = temp;
				temp = temp -> link;
			}
			t -> link = NULL;
			free(temp);
			temp = NULL;
			cnt--;
			return;
		}
	}
}

void delete_at_pos(int pos)
{
	printf("pos : %d\n", pos);
	if(pos == 0) {
		printf("0th node does not exists\n");
		return;
	} else if(pos == (cnt + 1)) {
		printf("%dth node does not exist\n", pos);
		return;
	} else if(pos == 1) {
		delete_at_beg();
		return;
	} else if(pos == cnt) {
		delete_at_end();
		return;
	} else {
		struct node *t;
		temp = start;
		while(--pos) {
			t = temp;
			temp = temp -> link;
			printf("data : %d\n", temp -> data);
			printf("tdata : %d\n", t -> data);
		}
		t -> link = temp -> link;
		free (temp);
		temp = NULL;
		cnt--;
		return;
	}
}

void delete_before_number(int num)
{
	int pos = del_search(num);
	if(pos == 0) {
		printf("Number not found \n");
		return;
	} else {
		delete_at_pos((pos));
		return;
	}
}

void delete_after_number(int num)
{
	int pos = del_search(num);
	if(pos == 0) {
		printf("Number not found \n");
		return;
	} else {
		delete_at_pos((pos + 1));
		return;
	}
}

void delete_at_mid(void)
{
	if((cnt & 1u) != 0) {
		delete_at_pos((cnt / 2) + 1);
	} else {
		delete_at_pos((cnt / 2));
	}
	return;
}

void delete_at_penultimate(void)
{
	delete_at_pos((cnt - 1));
}

int del_search(int data)
{
	pos = 0;
	temp = start;
	if(start == NULL) {
		return 0;
	} else if((temp -> data) == data) {
		return 1;
	} else {
		while(temp -> link != NULL) {
			temp = temp -> link;
			pos++;
		}

		return pos;
	}
}

void sll_display(void)
{
	system("clear");
	printf("Total no of nodes : %d\n", cnt);
	temp = start;
	if(start == NULL) {
		printf("List is empty\n");
		return;
	} else {
		while(temp -> link != NULL) {

			printf(" %d -> ", temp -> data);
			temp = temp -> link;
		}
		printf("%d\n", temp -> data);
		return;
	}
}
