
#include <stdio.h>
#include <stdlib.h>
#include "../Header/dsheader.h" /* This header will contain
								   all the extern declarations*/
#define SIZE 5

int main(void)
{
	char ch[SIZE];
	char input1[SIZE];
	char input2[SIZE];
	//	char choice[SIZE];
	/*	int choice1;
		int choice2;
		int choice3;*/


	printf("1.Stack Operations\n2.Queue Operations\n"
			"3.Circular queue operations");
	printf("\n4.Linked List Operations\n");
	printf("5.Double Linked List Operations\n6.Copy node to files\n");
	printf("Enter your choice : ");

	if(NULL == (fgets(ch, SIZE, stdin))) {
		perror("malloc failed\n");
		exit(1);
	}
	system("clear");

	switch(my_atoi(ch)) {
		case 1 :
			do {
				system("clear");
				printf("1.Push\n2.Pop\n3.Display\n");
				printf("Enter your choice : ");
				if(NULL == (fgets(input1, SIZE, stdin))) {
					perror("fgets failed");
					exit(1);
				}

				switch(my_atoi(input1)) {
					case 1 : push();	  //For pushing data onto the stack
							 break;

					case 2 : pop();		//For popping data out of the stack
							 break;

					case 3 : display();		//Displays all stack contents
							 break;
				}

				printf("Do you want to continue :\n 1.Yes\t2.No ");

				if(NULL == (fgets(input2, SIZE, stdin))) {
					perror("fgets failed\n");
					exit(1);
				}
			}while(my_atoi(input2) == 1);
			
			break;
		case 2 : 
			do {
				system("clear");
				printf("1.Enqueue\n2.Dequeue\n3.Display\n");
				if(NULL == (fgets(input1, SIZE, stdin))) {
					perror("fgets failed");
					exit(1);
				}

				switch(my_atoi(input1)) {
					case 1 : enqueue();
							 break;

					case 2 : dequeue();
							 break;

					case 3 : que_display();
							 break;
				}	

				printf("Do you want to continue :\n 1.Yes\t2.No ");

				if(NULL == (fgets(input2, SIZE, stdin))) {
					perror("fgets failed\n");
					exit(1);
				}
			}while(my_atoi(input2) == 1);
			break;
			
		case 3 :                                                                
			do {                                                                
				system("clear");                                                
				printf("1.Cir_Enqueue\n2.Cir_Dequeue\n3.Cir_Display\n");                    
				if(NULL == (fgets(input1, SIZE, stdin))) {                      
					perror("fgets failed");                                     
					exit(1);                                                    
				}                                                               

				switch(my_atoi(input1)) {                                       
					case 1 : cir_enque();                                         
							 break;                                             

					case 2 : cir_deque();                                         
							 break;                                             

					case 3 : cir_display();                                     
							 break;                                             
				}                                                               

				printf("Do you want to continue :\n 1.Yes\t2.No ");             

				if(NULL == (fgets(input2, SIZE, stdin))) {                      
					perror("fgets failed\n");                                   
					exit(1);                                                    
				}                                                               
			}while(my_atoi(input2) == 1);     
			break;
		case 4 : 
			do {                                                                
				system("clear");                                                
				printf("1.SingleLinkedListInsert\n");
				printf("2.Circular Single Linked List\n3.Exit\n");        
				if(NULL == (fgets(input1, SIZE, stdin))) {                      
					perror("fgets failed");                                     
					exit(1);                                                    
				}                                                               

				switch(my_atoi(input1)) {                                       
					case 1 : sll_insert_menu();                            
							 break;   
							 
					case 2 : cir_sll_menu();
						break;         

					case 3 : break;
				}                                                               

				printf("Do you want to continue :\n 1.Yes\t2.No ");             

				if(NULL == (fgets(input2, SIZE, stdin))) {                      
					perror("fgets failed\n");                                   
					exit(1);                                                    
				}                                                               
			}while(my_atoi(input2) == 1);
			break;
		case 5 : 
			do {                                                                
				system("clear");                                                
				printf("1.Double Linked List\n");
				printf("2.Circular Double Linked List\n3.Exit\n");        
				if(NULL == (fgets(input1, SIZE, stdin))) {                      
					perror("fgets failed");                                     
					exit(1);                                                    
				}                                                               

				switch(my_atoi(input1)) {                                       
					case 1 : dll_menu();                            
							 break;            

					case 3 : break;
				}                                                               

				printf("Do you want to continue :\n 1.Yes\t2.No ");             

				if(NULL == (fgets(input2, SIZE, stdin))) {                      
					perror("fgets failed\n");                                   
					exit(1);                                                    
				}                                                               
			}while(my_atoi(input2) == 1);
			break;
			
		case 6 : copy_node_to_file();
			break;
			
	}

	return 0;
}

