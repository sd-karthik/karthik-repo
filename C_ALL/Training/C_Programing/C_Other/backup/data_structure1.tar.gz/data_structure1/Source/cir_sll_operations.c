#include<stdio.h>
#include<stdlib.h>
#include "../Header/dsheader.h"

int c_pos = 1;
int c_cnt = 0;

struct c_node {
	int data;
	struct c_node *link;
};

struct c_node *last = NULL, *c_temp;

int isfirstc_node(void)
{
	if(last == NULL) {
		printf("Enter data (first c_node ) : ");
		c_temp = (struct c_node *) malloc (sizeof(struct c_node));
		scanf("%d", &(c_temp -> data));
		last = c_temp;
		c_temp -> link = last;
		c_cnt++;
		return 1;
	} else {
		return 0;
	}
}

void cir_insert_at_beg(void)
{
	if(isfirstc_node()) {

		printf("Data added successfully\n");
		return;

	} else if (last -> link == last) {
		printf("Enter data : ");
		c_temp = (struct c_node *) malloc (sizeof(struct c_node));
		scanf("%d", &(c_temp -> data));
		c_temp -> link = last;
		last -> link = c_temp;
		last = c_temp;
		c_cnt++;
		return;
	} else {
		struct c_node *t = last;
		printf("Enter data (insert at beg) : ");
		c_temp = (struct c_node *) malloc (sizeof(struct c_node));
		while(t -> link != last) {
			t = t -> link;
		}
		t -> link = c_temp;
		scanf("%d", &(c_temp -> data));
		c_temp -> link = last;
		last = c_temp;
		c_cnt++;
		return;
	}
}
void cir_insert_at_end(void)
{
	if(isfirstc_node()) {

		return;

	} else {
		struct c_node *t = last;

		while(t -> link != last) {

			t = t -> link;
		}

		printf("Enter data : ");
		c_temp = (struct c_node *) malloc (sizeof (struct c_node));
		scanf("%d", &(c_temp -> data));
		c_temp -> link = t -> link;
		t -> link = c_temp;
		c_cnt++;
	}
	return;
}
int cir_search(int data)
{
	c_pos = 0;
	c_temp = last;
	if (c_temp -> data ==  data) {
		return 1;
	} else {
		while(c_temp -> data != data) {

			c_temp = c_temp -> link;
			c_pos++;
		}
		return c_pos;
	}
}

void cir_insert_at_c_pos(int c_pos)
{
	if(c_pos < 0 || c_pos > (c_cnt + 1) ) {
		printf("Node does not exist \n");
		return;
	}
	else if(isfirstc_node()) {
		return;
	} else {
		printf("c_pos : %d\n", c_pos);
		if(c_pos == 0) {
			cir_insert_at_beg();
			return;
		} else if (c_pos == (c_cnt + 1)) {
			cir_insert_at_end();
			return;
		} else {
			if(c_pos <= c_cnt) {
				c_temp = last;
				while(--c_pos) {
					c_temp = c_temp -> link;
				}
				struct c_node *c_temp2 = (struct c_node *) malloc (sizeof(struct c_node));
				printf("Enter data : ");
				scanf("%d", &(c_temp2 -> data));
				c_temp2 -> link = c_temp -> link;
				c_temp -> link = c_temp2;
				c_cnt++;
				return;
			} else {
				printf("Enter a valid c_position less than %d ", c_cnt);
				return;
			}
		}
	}
}

void cir_insert_before_number(int num)
{
	int c_pos = cir_search(num);
	printf("pos : %d", c_pos);

	if(c_pos == 0) {
		printf("Number not found \n");
		return;
	} else {
		cir_insert_at_c_pos((c_pos - 1));
		return;
	}
}

void cir_insert_after_number(int num)
{
	int c_pos = cir_search(num);
	printf("pos : %d", c_pos);
	if(c_pos == 0) {
		printf("Number not found \n");
		return;
	} else {
		cir_insert_at_c_pos((c_pos + 1));
		return;
	}
}

void cir_insert_at_mid(void)
{
	cir_insert_at_c_pos((c_cnt/2));
	return;
}

void cir_insert_at_penultimate(void)
{
	cir_insert_at_c_pos((c_cnt - 1));
}

void cir_delete_at_beg(void)
{
	if(last == NULL) {
		printf("List is empty\n");
		return;
	} else if(last -> link == last) {
		c_temp = last;
		last = NULL;
		free(c_temp);
		c_temp = NULL;
		c_cnt--;
		return;
	} else {
	//	c_temp = last;
		last = c_temp -> link;
		struct c_node *t = last;
		while(t -> link != last) {
			t = t -> link;
		}
		t -> link = last;
		free(c_temp);
		c_cnt--;
		return;
	}
}

void cir_delete_at_end(void)
{
	if(last == NULL) {
		printf("List is empty\n ");
		return;
	} else {
		struct c_node *t;
		c_temp = last;

		if(c_temp -> link == NULL) {
			last = NULL;
			free(c_temp);
			c_temp = NULL;
			c_cnt--;
			return;
		} else  {
			while(c_temp -> link != NULL) {
				t = c_temp;
				c_temp = c_temp -> link;
			}
			t -> link = NULL;
			free(c_temp);
			c_temp = NULL;
			c_cnt--;
			return;
		}
	}
}

void cir_delete_at_c_pos(int c_pos)
{
	printf("c_pos : %d\n", c_pos);
	if(c_pos == 0) {
		printf("0th c_node does not exists\n");
		return;
	} else if(c_pos == (c_cnt + 1)) {
		printf("%dth c_node does not exist\n", c_pos);
		return;
	} else if(c_pos == 1) {
		cir_delete_at_beg();
		return;
	} else if(c_pos == c_cnt) {
		cir_delete_at_end();
		return;
	} else {
		struct c_node *t;
		c_temp = last;
		while(--c_pos) {
			t = c_temp;
			c_temp = c_temp -> link;
			printf("data : %d\n", c_temp -> data);
			printf("tdata : %d\n", t -> data);
		}
		t -> link = c_temp -> link;
		free (c_temp);
		c_temp = NULL;
		c_cnt--;
		return;
	}
}

void cir_delete_before_number(int num)
{
	int c_pos = cir_del_search(num);
	if(c_pos == 0) {
		printf("Number not found \n");
		return;
	} else {
		cir_delete_at_c_pos((c_pos));
		return;
	}
}

void cir_delete_after_number(int num)
{
	int c_pos = cir_del_search(num);
	if(c_pos == 0) {
		printf("Number not found \n");
		return;
	} else {
		cir_delete_at_c_pos((c_pos + 1));
		return;
	}
}

void cir_delete_at_mid(void)
{
	cir_delete_at_c_pos((c_cnt/2) + 1);
	return;
}

void cir_delete_at_penultimate(void)
{
	cir_delete_at_c_pos((c_cnt - 1));
	return;
}

int cir_del_search(int data)
{
	c_pos = 0;
	c_temp = last;
	if(last == NULL) {
		return 0;
	} else if((c_temp -> data) == data) {
		return 1;
	} else {
		while(c_temp -> link != NULL) {
			c_temp = c_temp -> link;
			c_pos++;
		}

		return c_pos;
	}
}

void cir_sll_display(void)
{
	system("clear");
	printf("Total no of c_nodes : %d\n", c_cnt);
	c_temp = last;
	if(last == NULL) {
		printf("List is empty\n");
		return;
	} else {
		while(c_temp -> link != last) {

			printf(" %d -> ", c_temp -> data);
			c_temp = c_temp -> link;
		}
		printf("%d\n", c_temp -> data);
		return;
	}
}
