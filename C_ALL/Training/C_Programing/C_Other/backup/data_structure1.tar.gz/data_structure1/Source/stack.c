#include<stdio.h>
#include<stdlib.h>
#include "../Header/dsheader.h"
#define MAX 5

int stack[MAX];
int top = -1;
char arr[MAX];

void push()		//Pushes data to stack
{

	int n;

	if(isfull()) {  	//checks if stack is full

		printf("Stack is full\n");
		return;

	} else {					//if stack is not full

		printf("Enter the element to push : ");

		if(NULL == (fgets(arr, MAX, stdin))) {
			perror("fgets failed");
			exit(1);
		}

		n = my_atoi(arr);
		stack[++top] = n;
		return;
	}
}

void pop(void)			//pop data from stack
{
	if(isempty()) {			//checks if stack is empty
		printf("stack is empty \n" );
		return;
	} else {			//pops data from stack
		top--;		
		return;
	}
}

void display(void)
{
	int i = top;

	if(isempty()) {
		printf("stack is empty \n");
		return;
	} else {					//prints values of stack
		while(i >= 0) {	
			printf("stack[%d] %d\n", i , stack[i]);
			i--;
		}
	}
	return;
}

int isfull()		//checks if stack is full
{
	return (top == (MAX - 1)) ? 1 : 0;
}

int isempty(void)		//checks if stack is empty
{
	return (top == -1 ) ? 1 : 0;
}
