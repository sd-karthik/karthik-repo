#include<stdio.h>
#include<stdlib.h>
#include "../Header/dsheader.h"
#define MAX 5

void sll_insert_menu(void)
{
	char choice[MAX];
	char input[MAX];
	int pos;
	int data;

	do {
		system("clear");
		printf("1.InsertAtBeg\t2.InsertAtEnd\n3.InsertAtGivenPos\t");
		printf("4.Insert Before Given Pos\n5.Insert after given position\t");
		printf("6.Insert before given number\n7.Insert after given number\t");
		printf("8.Insert at the middle\n9.Insert at penumltimate\n");
		printf("10.DeleteAtBeg\t11.DeleteAtEnd\n12.DeleteAtGivenPos\t");
		printf("13.Delete Before Given Pos\n14.Delete after given position\t");
		printf("15.Delete before given number\n16.Delete after given number\t");
		printf("17.Delete at the middle\n18.Delete at penumltimate\n19.Display\n");
		printf("20.Exit\n");

		if(NULL == (fgets(choice, MAX, stdin))) {

			perror("fgets failed\n");
			exit(1);
		}
		switch(my_atoi(choice)) {
			
			case 1 : insert_at_beg();
					 break;
					 
			case 2 : insert_at_end();
					 break;

			case 3 :
					 printf("Enter position : ");
					 scanf("%d",&pos);
					 insert_at_pos((pos - 1));
					 break;

			case 4 : printf("Enter position : ");
					 scanf("%d", &pos);
					 insert_at_pos((pos - 1));
					 break;

			case 5 : printf("Enter position : ");
					 scanf("%d", &pos);
					 insert_at_pos(pos);
					 break;

			case 6 : printf("Enter number : ");
					 scanf("%d", &data);
					 insert_before_number(data);
					 break;

			case 7 : printf("Enter data : ");
					 scanf("%d", &data);
					 insert_after_number(data);
					 break;
			case 8 : insert_at_mid();
					 break;
			case 9 : insert_at_penultimate();
					 break;
			case 10 : delete_at_beg();
					 break;

			case 11 : delete_at_end();
					 break;

			case 12 :
					 printf("Enter position : ");
					 scanf("%d",&pos);
					 delete_at_pos((pos));
					 break;

			case 13 : printf("Enter position : ");
					 scanf("%d", &pos);
					 delete_at_pos((pos - 1));
					 break;

			case 14 : printf("Enter position : ");
					 scanf("%d", &pos);
					 delete_at_pos((pos + 1));
					 break;

			case 15 : printf("Enter number : ");
					 scanf("%d", &data);
					 delete_before_number(data);
					 break;

			case 16 : printf("Enter data : ");
					 scanf("%d", &data);
					 delete_after_number(data);
					 break;

			case 17 : delete_at_mid();
					 break;

			case 18 : delete_at_penultimate();
					 break;

			case 19 : sll_display();
					  break;

			case 20 : exit(1);

			default : printf("Wrong choice \n");
					  break;
		}
		
		printf("Do you want to continue\n1.Yes\t2.No\n");
	
		if(NULL == (fgets(input, MAX, stdin))) {
			perror("fgets failed\n");
			exit(1);
		}
	}while(my_atoi(input) == 1);

}
