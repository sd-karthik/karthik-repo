
# include <stdio.h>
# include <stdlib.h>
# include "../Header/dsheader.h"
# define MAX 5
extern struct node *start, *temp;

void copy_node_to_file(void)
{
	char in[MAX];
	int n;
	int i;

	do {
		printf("Enter number of nodes you want to copy : ");
		if(NULL == (fgets(in, MAX, stdin))) {
			perror("fgets failed\n");
			exit(1);
		}
		n = my_atoi(in);
	}while(n == 0);

	for(i = 0; i < n; i++) {

		insert_at_beg();
	}

	temp = start;
	/*while(temp -> link != NULL) {
		
	}*/
}
