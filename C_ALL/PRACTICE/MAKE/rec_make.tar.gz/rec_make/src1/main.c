
# include "header.h"

int main() 
{
	printf("I am main\n"); 
	printf("Addition is %d\n", add(10, 20));
	printf("Substraction is %d\n", sub(20, 10));
	return 0;
}

