
# include "header.h"

int add(int a, int b) 
{
	printf("\nI am addition\n"); 
	return (a + b); 
}
