
# include "header.h"

int sub(int a, int b) 
{ 
	printf("\nI am substraction\n");
	return (a -b);
} 

