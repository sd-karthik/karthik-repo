
# ifndef __HEADER__
# define _HEADER__ 1

# include <stdio.h>
# include <stdlib.h>

int add(int , int );
int sub(int , int );

# endif
