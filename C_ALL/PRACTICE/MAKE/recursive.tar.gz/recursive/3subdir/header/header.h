#if!defined header
#define header 1
#include <stdio.h>
#include <stdlib.h>
#include <stdio_ext.h>
#define LEN 64
int bit_swap(int num, int dpos, int spos);
int enternum(char *val);
int enterdpos(char *dest);
int enterspos(char *src);
int my_atoi(char *ch);
int mstrlen(char *str);
#endif
