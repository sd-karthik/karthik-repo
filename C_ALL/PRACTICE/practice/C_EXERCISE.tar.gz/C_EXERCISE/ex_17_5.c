#include <stdio.h>
int main()
{
	printf("%%\b\\\n");
}
