#include	<stdio.h>
#include	<stdlib.h>

int main()
{
	int a[] = {0x12345678, 0x11223344, 3, 4, 5};
	char *ptr;

	ptr = (char *)a;
	printf("%x \n", ptr[7]);
	return 0;
}
