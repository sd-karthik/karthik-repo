# include <stdio.h>

int main()
{
		printf("\033[31m Hello world\n\033[m");
		return 0;
}
