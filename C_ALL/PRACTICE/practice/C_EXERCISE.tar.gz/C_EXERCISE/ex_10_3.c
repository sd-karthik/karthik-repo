#include <stdio.h>

int main()
{
	char *p = "sundar";
	char q[] = "pandi";
	int n;

	printf("%d\n", n);

	printf("Address of p ==> %08x\n", (unsigned ) p);
	printf("Address of q ==> %08x\n", (unsigned ) q);
	n = p - q;

	printf("%08x\n",(unsigned) n);
	return 0;
}
