#include<stdio.h>
unsigned char test_endian( void )
{
    int test_var = 0x1234;
    unsigned char *test_endian = (unsigned char*)&test_var;
    
#if 0
	unsigned char *test_endian1 = test_endian + 1;
	printf("test endian ==> %x\n", *test_endian);
	printf("test endian ==> %x\n", *test_endian1);

	printf("Test endian [0] ==> %d\n" ,test_endian[0]);
#endif
	return (test_endian[0] == NULL);
}
int main()
{
	if (test_endian())
		printf("big endian\n");
	else
		printf("little endian\n");
		
    return 0;
}
