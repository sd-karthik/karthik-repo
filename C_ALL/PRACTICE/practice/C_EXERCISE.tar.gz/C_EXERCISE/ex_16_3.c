#include <stdio.h>

int main()
{
	char *s = "globaledge";
	printf("$%9.*s$",  4, s);
	/* printf("\n"); */
	/* printf("%*d", 5, 10); */
	printf("\n");
}
