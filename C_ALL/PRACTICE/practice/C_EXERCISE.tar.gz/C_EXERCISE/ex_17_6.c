#include <stdio.h>
int main()
{
	close(0);
	printf("%c\n", 2["Hello"]);
}
