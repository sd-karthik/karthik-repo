#include <stdio.h>
int a;
int main()
{
	printf("%p \n", &a);
}
