#include<stdio.h>

int main()
{
    char ch = 'A';
	switch(ch) {
	printf("ssssssssss");
	    case 0:
		printf("0");
		break;
	    case 1:
		printf("1");
		break;
	    case 2:
		printf("2");
		break;
	    default:
		printf("3");
	}
    return 0;
}
