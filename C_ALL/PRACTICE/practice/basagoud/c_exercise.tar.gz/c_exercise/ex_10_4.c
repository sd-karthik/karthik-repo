#include	<stdio.h>

#define foo(m, n)  #m ## #n

int main()
{

	printf("%s\n", foo(k, l));

}
