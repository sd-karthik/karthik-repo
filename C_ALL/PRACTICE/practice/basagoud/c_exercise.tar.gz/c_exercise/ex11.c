#include <stdio.h>

int main()

{

		int x = 1, y = 0, z = 3;

		x > y ? printf("%d", z) : return z;

}
