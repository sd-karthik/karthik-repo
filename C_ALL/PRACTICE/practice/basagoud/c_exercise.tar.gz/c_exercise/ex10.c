#include	<stdio.h>
#include	<stdlib.h>

int main()
{
	unsigned char ch;
	ch = 1021;
	printf("%d \n", ch);
	return 0;
}
