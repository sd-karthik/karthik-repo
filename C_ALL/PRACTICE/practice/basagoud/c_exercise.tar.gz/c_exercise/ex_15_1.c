which function is used to find cuberoot of the number(64 --> 4) ?
csqrt
pow
sqrt
hypot
