#include	<stdio.h>
//#include "binconst.h"
int main() 
{
 char c[100] ;
 scanf("%*s %s",c);
 printf("str:%s\n",c);
}
